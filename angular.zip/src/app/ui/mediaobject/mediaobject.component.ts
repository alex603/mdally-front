import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mediaobject',
  templateUrl: './mediaobject.component.html',
  styleUrls: ['./mediaobject.component.css']
})
export class MediaobjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
