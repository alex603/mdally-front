import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-kit',
  templateUrl: './kit.component.html',
  styleUrls: ['./kit.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class KitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
